
 <?php 
/* session_start();
if (!isset($_SESSION['login'])) {
	$_SESSION['login']="incorreto";
}
if($_SESSION['login']=="correto"&& isset($_SESSION['login'])){
	//conteúdo

*/



//session_start();
$con=new mysqli("localhost","root","","papjogos");
if($con->connect_errno!=0){
	echo "Ocorreu um erro no acesso à base de dados".$con->connect_error;
	exit;
}
/*else{
	if(!isset($_SESSION['login'])){
		$_SESSION['login']="incorreto";
	}
	if($_SESSION['login']=="correto"){
*/



 ?>
<!DOCTYPE html>
<html >
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home | VP Gaming</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
  


    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	<header id="header"><!--header-->
		<div class="header_top"><!--header_top-->
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<div class="contactinfo">
							<ul class="nav nav-pills">
								<li><a href="#"><i class="fa fa-phone"></i> +2 95 01 88 821</a></li>
								<li><a href="#"><i class="fa fa-envelope"></i> vpgaming@gmail.com</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="social-icons pull-right">
							<ul class="nav navbar-nav">
								<li><a href="https://www.facebook.com/vp.gaming.980" target="_blank"><i class="fa fa-facebook"></i></a></li>
								<li><a href="https://twitter.com/VPGaming16" target="_blank"><i class="fa fa-twitter"></i></a></li>
								<li><a href="https://www.instagram.com/__vpgaming__/" target="_blank"><i class="fa fa-instagram"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header_top-->
		
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-md-4 clearfix">
						<div class="logo pull-left">
							<a href="index.php"><img src="images/home/logo.PNG" alt="" /></a>
						</div>
						<div class="btn-group pull-right clearfix">
							
						</div>
					</div>
					<div class="col-md-8 clearfix">
						<div class="shop-menu clearfix pull-right">
							<ul class="nav navbar-nav">
								<li><a href=""><i class="fa fa-user"></i> Account</a></li>

								
								<li><a href="login.php"><i class="fa fa-lock"></i> Login</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-middle-->
	
		<div class="header-bottom"><!--header-bottom-->
			<div class="container">
				<div class="row">
					<div class="col-sm-9">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
						<div class="mainmenu pull-left">
							<ul class="nav navbar-nav collapse navbar-collapse">
								<li><a href="index.php" class="active">Home</a></li>
								<li class="dropdown"><a href="#">Shop<i class="fa fa-angle-down"></i></a>
                                    <ul role="menu" class="sub-menu">
                                        <li><a href="shop.html">Products</a></li>
										 
										
										<li><a href="login.php">Login</a></li> 
                                    </ul>
                               
								<li><a href="contact-us.html">Requests</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="search_box pull-right">
							<!--<input type="text" placeholder="Search"/>-->
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-bottom-->
	</header><!--/header-->
	
	<section id="slider"><!--slider-->
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div id="slider-carousel" class="carousel slide" data-ride="carousel">
						<ol class="carousel-indicators">
							<li data-target="#slider-carousel" data-slide-to="0" class="active"></li>
							<li data-target="#slider-carousel" data-slide-to="1"></li>
							<li data-target="#slider-carousel" data-slide-to="2"></li>
						</ol>
						
						<div class="carousel-inner">
<?php 

$teste=0;

$stm=$con->prepare('select * from galeria');
$stm->execute();
$res=$stm->get_result();
while ( $resultado=$res->fetch_assoc() ) {
if($teste==0){
	echo ' <div class="item active">';
	$teste=1;
}

else{

	echo ' <div class="item ">';
	}

echo '<div class="col-sm-6">
			<h1><span>VP</span>-Gaming</h1>
			<h2>'.$resultado['titulo'].'</h2>
			<p>'.$resultado['descricao'].'</p>
			
			<br><br>
		</div>
		<div class="col-sm-6">';

	echo		'	<img width="1000px" height="1000px" src="images/home/fifa21.jpg" class="girl img-responsive" alt="" />';

	echo '</div>
	</div>';


}
$stm->close();
 ?>



							



							
							
						</div>
						
						<a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
							<i class="fa fa-angle-left"></i>
						</a>
						<a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
							<i class="fa fa-angle-right"></i>
						</a>
					</div>
					
				</div>
			</div>
		</div>
	</section><!--/slider-->
	
	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>PLATAFORM</h2>
						<div class="panel-group category-products" id="accordian"><!--category-productsr-->
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#sportswear">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											Playstation
										</a>
									</h4>
								</div>
								<div id="sportswear" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="playstation.html">PLAYSTATION GAMES</a></li>
											<li><a href="#"> </a></li>
											
										</ul>
									</div>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#mens">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											Xbox
										</a>
									</h4>
								</div>
								<div id="mens" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="xbox.html">XBOX GAMES</a></li>
											<li><a href="#"></a></li>
											
										</ul>
									</div>
								</div>
							</div>
							
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#womens">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											Nintendo
										</a>
									</h4>
								</div>
								<div id="womens" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="nintendo.html">NINTENDO GAMES</a></li>
											<li><a href="#"></a></li>
											
										</ul>
									</div>
								</div>
							</div>
							
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#pcs">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											PC GAMING
										</a>
									</h4>
								</div>
								<div id="pcs" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="pc.html">PC GAMES</a></li>
											<li><a href="#"></a></li>
											
										</ul>
									</div>
								</div>
							</div>
							
						</div><!--/category-products-->
					
						<div class="brands_products"><!--brands_products-->
							<h2>CATEGORIES</h2>
							<div class="brands-name">
								<ul class="nav nav-pills nav-stacked">
									<li><a href="#"> <span class="pull-right">(3)</span>SPORT</a></li>
									<li><a href="#"> <span class="pull-right">(1)</span>WAR</a></li>
									<li><a href="#"> <span class="pull-right">(2)</span>ACTION</a></li>
									<li><a href="#"> <span class="pull-right">(2)</span>ADVENTURE</a></li>
									
									
								</ul>
							</div>
						</div><!--/brands_products-->
						
						
						
					
					</div>
				</div>
				
				
					
					<div class="category-tab">
						<div class="col-sm-12">
							
								<h2 align="center"> Popular</h2>

								
							</ul>
						</div>
						<div class="tab-content">
							<div class="tab-pane fade active in" id="popular" >
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/fifa21.jpg" alt="" width="40" height="105"/>
												<h2>$50</h2>
												<p>FIFA 21</p>
												<a href="contact-us.html" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>BUY</a>
											</div>
											
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/minecraft.jpg" alt="" width="40" height="105" />
												<h2>$20</h2>
												<p>MINECRAFT</p>
												<a href="contact-us.html" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>BUY</a>
											</div>
											<img src="images/home/sale.png" class="new" alt=""  height="45px" />
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/gtaV.jpg" alt="" width="40" height="105" />
												<h2>$60</h2>
												<p>GTA V</p>
												<a href="contact-us.html" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>BUY</a>
											</div>
											
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/motogp.jpg" alt="" width="40" height="105" />
												<h2>$65</h2>
												<p>MOTOGP 21</p>
												<a href="contact-us.html" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>BUY</a>
											</div>
											
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/supermarioparty.jpg" alt="" width="40" height="105" />
												<h2>$10</h2>
												<p>SUPER MARIO PARTY</p>
												<a href="contact-us.html" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>BUY</a>
											</div>
											<img src="images/home/new.png" class="new" alt=""  height="45px" />
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/pes21.jpg" alt="" width="40" height="105" />
												<h2>$40</h2>
												<p>PES 21</p>
												<a href="contact-us.html" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>BUY</a>
											</div>
											
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/valorant.jpg" alt="" width="40" height="105" />
												<h2>FREE</h2>
												<p>VALORANT</p>
												<a href="contact-us.html" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>BUY</a>
											</div>
											
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/lol.jpg" alt="" width="40" height="105" />
												<h2>$10</h2>
												<p>LEAGUE OF LEGENDS</p>
												<a href="contact-us.html" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>BUY</a>
											</div>
											
										</div>
									</div>
								</div>
							</div>
							

				</div>
			</div>
		</div>
	</section>
	
	
		<hr>

<div align="left" class="col-lg-4 col-md-12">
<div class="delivery methods block one"><img src="https://static.pcdiga.com/media/icons/ic-ecommerce-delivery_2x.png" alt="">
<p class="delivery methods title">Entregas em 24 horas</p>
<p>Tempo médio em dias úteis para Portugal Continental</p>
</div>
</div>
<div align="center" class="col-lg-4 col-md-12">
<div class="delivery methods block two"><img src="https://static.pcdiga.com/media/icons/ic-ecommerce-house_2x.png" alt="">
<p class="delivery methods title">Levante na Loja</p>
<p>Compre online e levante a sua encomenda na loja VPGaming</p>
</div>
</div>
<div align="right" class="col-lg-4 col-md-12">
<div class="delivery methods block three"><img src="https://static.pcdiga.com/media/icons/Group_16045_2x.png" alt="">
<p  class="delivery methods title">Portes Grátis</p>
<p>Em compras superiores a 200€ para Portugal Continental</p>
</div>
</div>
</div>

    <script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.scrollUp.min.js"></script>
	<script src="js/price-range.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
